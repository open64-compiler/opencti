#ifdef __cplusplus
#error FT17 expected C frontend
#endif
#include "value.h"
#define LANGUAGE "C"
#define INPUT_FILE "input.c.link"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main(void) {
    char input[64], helper[64];
    FILE *f = fopen(INPUT_FILE, "r");
    if (!f || !fgets(input, sizeof input, f)) return 21;
    fclose(f); input[strcspn(input, "\n")] = 0;
    if (system("./alias.link > helper.out") != 0) return 22;
    f = fopen("helper.out", "r");
    if (!f || !fgets(helper, sizeof helper, f)) return 23;
    fclose(f); helper[strcspn(helper, "\n")] = 0;
    printf(LANGUAGE "|%s|%s|%d\n", input, helper, VALUE);
    return 0;
}
