FT17 intentionally non-executable alternate
