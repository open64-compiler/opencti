#!/bin/sh
printf "helper-ready\n"
