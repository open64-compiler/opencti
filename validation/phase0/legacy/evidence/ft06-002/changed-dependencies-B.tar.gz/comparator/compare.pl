#!/usr/bin/perl
print STDERR "FT06_COMPARATOR_B\n";
exit 0;
