const char *ft06_runtime(void) { return "runtime-B"; }
