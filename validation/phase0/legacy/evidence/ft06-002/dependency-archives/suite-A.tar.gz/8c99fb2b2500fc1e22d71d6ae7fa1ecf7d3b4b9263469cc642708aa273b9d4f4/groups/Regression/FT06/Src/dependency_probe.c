#include <stdio.h>
#include "consumed.h"
extern const char *ft06_runtime(void);
int main(int argc, char **argv) {
    char data[80];
    if (argc != 2) return 10;
    FILE *file = fopen(argv[1], "r");
    if (!file || !fgets(data, sizeof(data), file)) return 11;
    fclose(file);
    for (char *p = data; *p; ++p) if (*p == '\n') *p = 0;
    printf("%s|%s|%s|%s\n", FT06_COMPILER_ID, ft06_runtime(), data, CONSUMED_HEADER);
    return 0;
}
