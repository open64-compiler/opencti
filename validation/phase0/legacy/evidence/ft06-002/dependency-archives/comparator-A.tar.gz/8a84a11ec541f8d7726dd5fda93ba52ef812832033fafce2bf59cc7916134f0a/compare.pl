#!/usr/bin/perl
use strict;
use warnings;
my ($test, $actual, $master) = @ARGV;
print STDERR "FT06_COMPARATOR_A\n";
open(my $a, '<', $actual) or die "missing actual: $!";
open(my $m, '<', $master) or die "missing master: $!";
local $/;
my $left = <$a>; my $right = <$m>;
print "DiffPgmOut\n" if $left ne $right;
exit 0;
