#!/bin/bash
set -eu
. /case/environment.sh
export LD_LIBRARY_PATH=/toolchain/current/be:/toolchain/current/wopt:/toolchain/current/lno:/toolchain/current/ipl:/toolchain/current/whirl2c
/toolchain/current/ir_tools/ir_b2a -st -src /case/compatible/short.N /case/compatible/short.T
exec /toolchain/current/ir_tools/ir_b2a -st -src /case/positive/short.N /case/positive/short.T
