#!/bin/bash
set -eu
. /case/environment.sh
export LD_LIBRARY_PATH=/toolchain/old/be:/toolchain/old/wopt:/toolchain/old/lno:/toolchain/old/ipl:/toolchain/old/whirl2c
mkdir -p /case/failure
rm -f /case/failure/short.o /case/failure/short.N /case/failure/short.phase.t
exec /toolchain/old/be/be -fB,/case/short.input.B -fo,/case/failure/short.o -ft,/case/failure/short.phase.t -PHASE:l=on:w=off:c=off:lpath=/toolchain/old/lno:wpath=/toolchain/old/wopt -O3 -DSL:ai_opt_trace=on -tr25 -tt25:1 -OPT:IEEE_arith=3:roundoff=2 -DSL:partition_axis=on /src/osprey/torch2whirl/python/tests/models/absorbed_mla.py
