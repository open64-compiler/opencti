#!/bin/bash
set -eu
. /case/environment.sh
export LD_LIBRARY_PATH=/toolchain/current/be:/toolchain/current/wopt:/toolchain/current/lno:/toolchain/current/ipl:/toolchain/current/whirl2c
mkdir -p /case/source-lowering
/toolchain/current/ir_tools/tensor_kernel_lower prepare /case/source-DSL.B /case/source-lowering/recipe.json --verify 3
/toolchain/current/ir_tools/tensor_kernel_lower high /case/source-lowering/recipe.json /case/source-lowering/source.before.B /case/source-lowering/source.after.B /case/source-lowering/source.high.json
exec /toolchain/current/ir_tools/ir_b2a -st -src /case/source-lowering/source.after.B /case/source-lowering/source.after.T
