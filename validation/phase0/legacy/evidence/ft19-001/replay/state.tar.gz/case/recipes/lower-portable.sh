#!/bin/bash
set -eu
. /case/environment.sh
export LD_LIBRARY_PATH=/toolchain/current/be:/toolchain/current/wopt:/toolchain/current/lno:/toolchain/current/ipl:/toolchain/current/whirl2c
mkdir -p /case/positive
rm -f /case/positive/short.o /case/positive/short.N /case/positive/short.phase.t
exec /toolchain/current/be/be -fB,/case/short.input.B -fo,/case/positive/short.o -ft,/case/positive/short.phase.t -PHASE:l=on:w=off:c=off:lpath=/toolchain/current/lno:wpath=/toolchain/current/wopt -O3 -DSL:ai_opt_trace=on -tr25 -tt25:1 -OPT:IEEE_arith=3:roundoff=0 -LNO:simd=0 -DSL:partition_axis=on /src/osprey/torch2whirl/python/tests/models/absorbed_mla.py
