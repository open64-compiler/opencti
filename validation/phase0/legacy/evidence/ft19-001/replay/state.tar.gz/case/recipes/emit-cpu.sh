#!/bin/bash
set -eu
. /case/environment.sh
export LD_LIBRARY_PATH=/toolchain/current/be:/toolchain/current/wopt:/toolchain/current/lno:/toolchain/current/ipl:/toolchain/current/whirl2c
exec /toolchain/current/whirl2c/whirl2c -TARG:abi=n64 -O0 -CLIST:dotc_file=/case/positive/short.c -CLIST:doth_file=/case/positive/short.h -ft,/case/positive/emit.phase.t /case/positive/short.N
