/*******************************************************
 * C file translated from WHIRL Fri Nov 13 08:28:41 2026
 *******************************************************/

/* Include file-level type and variable decls */
#include "/case/positive/short.h"


extern void open64_common_high(
  _IEEE32 * restrict storage_0,
  _IEEE32 * restrict storage_1,
  _IEEE32 * restrict storage_2,
  _IEEE32 * restrict storage_3,
  _IEEE32 * restrict storage_4,
  _IEEE32 * restrict storage_5,
  _UINT8 * restrict storage_6,
  _IEEE32 * restrict storage_7,
  _IEEE32 * restrict storage_8,
  _IEEE32 * restrict storage_10,
  _IEEE32 * restrict storage_14,
  _IEEE32 * restrict storage_15,
  _IEEE32 * restrict storage_19,
  _IEEE32 * restrict storage_20,
  _IEEE32 * restrict storage_22,
  _IEEE32 * restrict storage_23,
  _IEEE32 * restrict storage_24,
  _UINT8 * restrict storage_25,
  _IEEE32 * restrict storage_26,
  _IEEE32 * restrict storage_27,
  _IEEE32 * restrict storage_28,
  _UINT8 * restrict storage_29,
  _IEEE32 * restrict storage_30,
  _IEEE32 * restrict storage_31,
  _IEEE32 * restrict storage_32,
  _IEEE32 * restrict storage_33,
  _IEEE32 * restrict storage_34,
  _IEEE32 * restrict storage_35,
  _UINT8 * restrict storage_36,
  _IEEE32 * restrict storage_37,
  _IEEE32 * restrict storage_38,
  _IEEE32 * restrict storage_39,
  _IEEE32 * restrict storage_42,
  _IEEE32 * restrict storage_45,
  _IEEE32 * restrict storage_46,
  _IEEE32 * restrict storage_48,
  _UINT8 * restrict storage_49,
  _IEEE32 * restrict storage_50,
  _IEEE32 * restrict storage_51,
  _IEEE32 * restrict storage_52,
  _IEEE32 * restrict storage_53)
{
  
  register _IEEE32 _w2c_mi0;
  register _IEEE32 _w2c_mi1;
  register _IEEE32 _w2c_mi2;
  register _IEEE32 _w2c_mi3;
  register _IEEE32 _w2c_mi4;
  register _IEEE32 _w2c_mi5;
  register _IEEE32 _w2c_mi6;
  register _IEEE32 _w2c_mi7;
  register _IEEE32 _w2c_mi8;
  register _IEEE32 _w2c_mi9;
  register _IEEE32 _w2c_mi10;
  register _IEEE32 _w2c_mi11;
  register _IEEE32 _w2c_mi12;
  register _IEEE32 _w2c_mi13;
  register _IEEE32 _w2c_mi14;
  register _INT64 _w2c_wd_contribution;
  register _IEEE32 _w2c_mi15;
  register _IEEE32 _w2c_mi16;
  register _IEEE32 _w2c_mi17;
  register _INT64 _w2c_axis_17;
  register _INT64 _w2c_axis_28;
  register _INT64 _w2c_axis_19;
  register _INT64 _w2c_contribution1;
  register _INT64 _w2c_axis_23;
  register _INT64 _w2c_axis_20;
  register _INT64 _w2c_axis_29;
  register _IEEE32 _w2c_mi18;
  register _IEEE32 _w2c_mi19;
  register _IEEE32 _w2c_mi20;
  register _IEEE32 _w2c_mi21;
  register _INT64 _w2c_axis_21;
  register _IEEE32 _w2c_ordered_sum0;
  register _INT64 _w2c______axis_2_1_3_5_7_9;
  register _IEEE32 _w2c_mi22;
  register _IEEE32 _w2c_mi23;
  register _IEEE32 _w2c_mi24;
  register _INT64 _w2c_contribution2;
  register _INT64 _w2c___axis_1_10_11;
  register _IEEE32 _w2c_mi25;
  register _IEEE32 _w2c_mi26;
  register _IEEE32 _w2c_mi27;
  register _INT64 _w2c_axis_24;
  register _INT64 _w2c_axis_25;
  register _INT64 _w2c_axis_30;
  register _IEEE32 _w2c_mi28;
  register _IEEE32 _w2c_mi29;
  register _IEEE32 _w2c_mi30;
  register _INT64 _w2c_contribution3;
  register _INT64 _w2c____axis_1_12_13_14;
  register _IEEE32 _w2c_storage_39_1;
  register _IEEE32 _w2c_storage_39_;
  register _IEEE32 _w2c_storage_39_0;
  register _INT64 _w2c_axis_27;
  register _INT64 _w2c_axis_;
  register _IEEE32 _w2c_mi31;
  register _IEEE32 _w2c_mi32;
  register _IEEE32 _w2c_mi33;
  register _IEEE32 _w2c_mi34;
  register _IEEE32 _w2c_mi35;
  register _IEEE32 _w2c_mi36;
  register _IEEE32 _w2c_mi37;
  register _IEEE32 _w2c_mi38;
  register _IEEE32 _w2c_mi39;
  register _IEEE32 _w2c_mi40;
  register _IEEE32 _w2c_mi41;
  register _IEEE32 _w2c_mi42;
  register _IEEE32 _w2c_mi43;
  register _IEEE32 _w2c_mi44;
  register _IEEE32 _w2c_mi45;
  register _INT64 _w2c_contribution0;
  register _IEEE32 _w2c_mi46;
  register _IEEE32 _w2c_mi47;
  register _IEEE32 _w2c_mi48;
  register _INT64 _w2c_axis_16;
  register _INT64 _w2c_axis_18;
  register _INT64 _w2c_axis_31;
  register _INT64 _w2c_axis_22;
  register _INT64 _w2c_contribution4;
  register _IEEE32 _w2c_mi49;
  register _IEEE32 _w2c_mi50;
  register _IEEE32 _w2c_mi51;
  register _IEEE32 _w2c_mi52;
  register _IEEE32 _w2c_mi53;
  register _IEEE32 _w2c_mi54;
  register _IEEE32 _w2c_mi55;
  register _IEEE32 _w2c_mi56;
  register _IEEE32 _w2c_mi57;
  register _IEEE32 _w2c_mi58;
  register _IEEE32 _w2c_mi59;
  register _IEEE32 _w2c_mi60;
  register _INT64 _w2c______axis_1_16_17_18_19_20;
  register _INT64 _w2c_axis_26;
  register _INT64 _w2c_axis_0;
  _INT64 axis_1;
  _INT64 axis_2;
  _INT64 axis_3;
  _IEEE32 ordered_sum;
  
  for(axis_1 = 0U; axis_1 <= 2LL; axis_1 = axis_1 + (_INT64)(1U))
  {
    for(axis_3 = 0U; axis_3 <= 15LL; axis_3 = axis_3 + (_INT64)(1U))
    {
      (storage_10)[axis_3 + (axis_1 * (_INT64)(16U))] = 0.0F;
    }
  }
  _w2c_mi0 = (storage_0)[0LL];
  _w2c_mi1 = (storage_0)[8LL];
  _w2c_mi2 = (storage_0)[20LL];
  _w2c_mi3 = (storage_0)[16LL];
  _w2c_mi4 = (storage_0)[12LL];
  _w2c_mi5 = (storage_0)[1LL];
  _w2c_mi6 = (storage_0)[4LL];
  _w2c_mi7 = (storage_0)[9LL];
  _w2c_mi8 = (storage_0)[19LL];
  _w2c_mi9 = (storage_0)[17LL];
  _w2c_mi10 = (storage_0)[11LL];
  _w2c_mi11 = (storage_0)[2LL];
  _w2c_mi12 = (storage_0)[3LL];
  _w2c_mi13 = (storage_0)[10LL];
  _w2c_mi14 = (storage_0)[18LL];
  for(axis_3 = 0U; axis_3 <= 15LL; axis_3 = axis_3 + (_INT64)(1U))
  {
    (storage_10)[axis_3] = (storage_10)[axis_3] + ((storage_4)[axis_3] * _w2c_mi0);
    (storage_10)[axis_3 + 16LL] = (storage_10)[axis_3 + 16LL] + ((storage_4)[axis_3 + 128LL] * _w2c_mi1);
    (storage_10)[axis_3 + 32LL] = (storage_10)[axis_3 + 32LL] + ((storage_4)[axis_3 + 256LL] * _w2c_mi3);
    (storage_10)[axis_3] = (storage_10)[axis_3] + ((storage_4)[axis_3 + 16LL] * _w2c_mi5);
    (storage_10)[axis_3 + 16LL] = (storage_10)[axis_3 + 16LL] + ((storage_4)[axis_3 + 144LL] * _w2c_mi7);
    (storage_10)[axis_3 + 32LL] = (storage_10)[axis_3 + 32LL] + ((storage_4)[axis_3 + 272LL] * _w2c_mi9);
    (storage_10)[axis_3] = (storage_10)[axis_3] + ((storage_4)[axis_3 + 32LL] * _w2c_mi11);
    (storage_10)[axis_3 + 16LL] = (storage_10)[axis_3 + 16LL] + ((storage_4)[axis_3 + 160LL] * _w2c_mi13);
    (storage_10)[axis_3 + 32LL] = (storage_10)[axis_3 + 32LL] + ((storage_4)[axis_3 + 288LL] * _w2c_mi14);
    (storage_10)[axis_3] = (storage_10)[axis_3] + ((storage_4)[axis_3 + 48LL] * _w2c_mi12);
    (storage_10)[axis_3 + 16LL] = (storage_10)[axis_3 + 16LL] + ((storage_4)[axis_3 + 176LL] * _w2c_mi10);
    (storage_10)[axis_3 + 32LL] = (storage_10)[axis_3 + 32LL] + ((storage_4)[axis_3 + 304LL] * _w2c_mi8);
    (storage_10)[axis_3] = (storage_10)[axis_3] + ((storage_4)[axis_3 + 64LL] * _w2c_mi6);
    (storage_10)[axis_3 + 16LL] = (storage_10)[axis_3 + 16LL] + ((storage_4)[axis_3 + 192LL] * _w2c_mi4);
    (storage_10)[axis_3 + 32LL] = (storage_10)[axis_3 + 32LL] + ((storage_4)[axis_3 + 320LL] * _w2c_mi2);
  }
  for(_w2c_wd_contribution = 5U; _w2c_wd_contribution <= 7LL; _w2c_wd_contribution = _w2c_wd_contribution + (_INT64)(1U))
  {
    _w2c_mi15 = (storage_0)[_w2c_wd_contribution];
    _w2c_mi16 = (storage_0)[_w2c_wd_contribution + 8LL];
    _w2c_mi17 = (storage_0)[_w2c_wd_contribution + 16LL];
    for(axis_3 = 0U; axis_3 <= 15LL; axis_3 = axis_3 + (_INT64)(1U))
    {
      (storage_10)[axis_3] = (storage_10)[axis_3] + ((storage_4)[axis_3 + (_w2c_wd_contribution * (_INT64)(16U))] * _w2c_mi15);
      (storage_10)[axis_3 + 16LL] = (storage_10)[axis_3 + 16LL] + ((storage_4)[(axis_3 + (_w2c_wd_contribution * (_INT64)(16U))) + 128LL] * _w2c_mi16);
      (storage_10)[axis_3 + 32LL] = (storage_10)[axis_3 + 32LL] + ((storage_4)[(axis_3 + (_w2c_wd_contribution * (_INT64)(16U))) + 256LL] * _w2c_mi17);
    }
  }
  for(axis_2 = 0U; axis_2 <= 15LL; axis_2 = axis_2 + (_INT64)(2U))
  {
    for(_w2c_axis_17 = 0U; _w2c_axis_17 <= 126LL; _w2c_axis_17 = _w2c_axis_17 + (_INT64)(1U))
    {
      (storage_14)[_w2c_axis_17 + (axis_2 * (_INT64)(127U))] = (storage_2)[axis_2 + (_w2c_axis_17 * (_INT64)(16U))];
      (storage_14)[_w2c_axis_17 + ((axis_2 + 1LL) * (_INT64)(127U))] = (storage_2)[(axis_2 + (_w2c_axis_17 * (_INT64)(16U))) + 1LL];
    }
  }
  for(_w2c_axis_28 = 0U; _w2c_axis_28 <= 2LL; _w2c_axis_28 = _w2c_axis_28 + (_INT64)(1U))
  {
    for(_w2c_axis_19 = 0U; _w2c_axis_19 <= 126LL; _w2c_axis_19 = _w2c_axis_19 + (_INT64)(1U))
    {
      ordered_sum = 0.0F;
      for(_w2c_contribution1 = 0U; _w2c_contribution1 <= 15LL; _w2c_contribution1 = _w2c_contribution1 + (_INT64)(1U))
      {
        ordered_sum = ordered_sum + ((storage_10)[_w2c_contribution1 + (_w2c_axis_28 * (_INT64)(16U))] * (storage_14)[_w2c_axis_19 + (_w2c_contribution1 * (_INT64)(127U))]);
      }
      (storage_15)[_w2c_axis_19 + (_w2c_axis_28 * (_INT64)(127U))] = ordered_sum;
    }
  }
  for(_w2c_axis_23 = 0U; _w2c_axis_23 <= 3LL; _w2c_axis_23 = _w2c_axis_23 + (_INT64)(2U))
  {
    for(_w2c_axis_20 = 0U; _w2c_axis_20 <= 126LL; _w2c_axis_20 = _w2c_axis_20 + (_INT64)(1U))
    {
      (storage_19)[_w2c_axis_20 + (_w2c_axis_23 * (_INT64)(127U))] = (storage_3)[_w2c_axis_23 + (_w2c_axis_20 * (_INT64)(4U))];
      (storage_19)[_w2c_axis_20 + ((_w2c_axis_23 + 1LL) * (_INT64)(127U))] = (storage_3)[(_w2c_axis_23 + (_w2c_axis_20 * (_INT64)(4U))) + 1LL];
    }
  }
  for(_w2c_axis_29 = 0U; _w2c_axis_29 <= 2LL; _w2c_axis_29 = _w2c_axis_29 + (_INT64)(1U))
  {
    _w2c_mi18 = (storage_1)[_w2c_axis_29 * (_INT64)(4U)];
    _w2c_mi19 = (storage_1)[(_w2c_axis_29 * (_INT64)(4U)) + 1LL];
    _w2c_mi20 = (storage_1)[(_w2c_axis_29 * (_INT64)(4U)) + 2LL];
    _w2c_mi21 = (storage_1)[(_w2c_axis_29 * (_INT64)(4U)) + 3LL];
    for(_w2c_axis_21 = 0U; _w2c_axis_21 <= 126LL; _w2c_axis_21 = _w2c_axis_21 + (_INT64)(1U))
    {
      _w2c_ordered_sum0 = 0.0F;
      _w2c_ordered_sum0 = _w2c_ordered_sum0 + ((storage_19)[_w2c_axis_21] * _w2c_mi18);
      _w2c_ordered_sum0 = _w2c_ordered_sum0 + ((storage_19)[_w2c_axis_21 + 127LL] * _w2c_mi19);
      _w2c_ordered_sum0 = _w2c_ordered_sum0 + ((storage_19)[_w2c_axis_21 + 254LL] * _w2c_mi20);
      _w2c_ordered_sum0 = _w2c_ordered_sum0 + ((storage_19)[_w2c_axis_21 + 381LL] * _w2c_mi21);
      (storage_20)[_w2c_axis_21 + (_w2c_axis_29 * (_INT64)(127U))] = _w2c_ordered_sum0;
    }
  }
  for(_w2c______axis_2_1_3_5_7_9 = 0U; _w2c______axis_2_1_3_5_7_9 <= 126LL; _w2c______axis_2_1_3_5_7_9 = _w2c______axis_2_1_3_5_7_9 + (_INT64)(1U))
  {
    (storage_22)[_w2c______axis_2_1_3_5_7_9] = (storage_15)[_w2c______axis_2_1_3_5_7_9] + (storage_20)[_w2c______axis_2_1_3_5_7_9];
    (storage_23)[_w2c______axis_2_1_3_5_7_9] = 2.8867512941e-01F;
    (storage_24)[_w2c______axis_2_1_3_5_7_9] = (storage_22)[_w2c______axis_2_1_3_5_7_9] * (storage_23)[_w2c______axis_2_1_3_5_7_9];
    (storage_25)[_w2c______axis_2_1_3_5_7_9] = (_UINT32)((storage_6)[_w2c______axis_2_1_3_5_7_9]) == 0U;
    (storage_26)[_w2c______axis_2_1_3_5_7_9] = -infF;
    (storage_27)[_w2c______axis_2_1_3_5_7_9] = ((storage_25)[_w2c______axis_2_1_3_5_7_9] ? (storage_26)[_w2c______axis_2_1_3_5_7_9] : (storage_24)[_w2c______axis_2_1_3_5_7_9]);
    (storage_22)[_w2c______axis_2_1_3_5_7_9 + 127LL] = (storage_15)[_w2c______axis_2_1_3_5_7_9 + 127LL] + (storage_20)[_w2c______axis_2_1_3_5_7_9 + 127LL];
    (storage_23)[_w2c______axis_2_1_3_5_7_9 + 127LL] = 2.8867512941e-01F;
    (storage_24)[_w2c______axis_2_1_3_5_7_9 + 127LL] = (storage_22)[_w2c______axis_2_1_3_5_7_9 + 127LL] * (storage_23)[_w2c______axis_2_1_3_5_7_9 + 127LL];
    (storage_25)[_w2c______axis_2_1_3_5_7_9 + 127LL] = (_UINT32)((storage_6)[_w2c______axis_2_1_3_5_7_9 + 127LL]) == 0U;
    (storage_26)[_w2c______axis_2_1_3_5_7_9 + 127LL] = -infF;
    (storage_27)[_w2c______axis_2_1_3_5_7_9 + 127LL] = ((storage_25)[_w2c______axis_2_1_3_5_7_9 + 127LL] ? (storage_26)[_w2c______axis_2_1_3_5_7_9 + 127LL] : (storage_24)[_w2c______axis_2_1_3_5_7_9 + 127LL]);
    (storage_22)[_w2c______axis_2_1_3_5_7_9 + 254LL] = (storage_15)[_w2c______axis_2_1_3_5_7_9 + 254LL] + (storage_20)[_w2c______axis_2_1_3_5_7_9 + 254LL];
    (storage_23)[_w2c______axis_2_1_3_5_7_9 + 254LL] = 2.8867512941e-01F;
    (storage_24)[_w2c______axis_2_1_3_5_7_9 + 254LL] = (storage_22)[_w2c______axis_2_1_3_5_7_9 + 254LL] * (storage_23)[_w2c______axis_2_1_3_5_7_9 + 254LL];
    (storage_25)[_w2c______axis_2_1_3_5_7_9 + 254LL] = (_UINT32)((storage_6)[_w2c______axis_2_1_3_5_7_9 + 254LL]) == 0U;
    (storage_26)[_w2c______axis_2_1_3_5_7_9 + 254LL] = -infF;
    (storage_27)[_w2c______axis_2_1_3_5_7_9 + 254LL] = ((storage_25)[_w2c______axis_2_1_3_5_7_9 + 254LL] ? (storage_26)[_w2c______axis_2_1_3_5_7_9 + 254LL] : (storage_24)[_w2c______axis_2_1_3_5_7_9 + 254LL]);
  }
  (storage_28)[0LL] = -infF;
  (storage_28)[1LL] = -infF;
  (storage_28)[2LL] = -infF;
  _w2c_mi22 = (storage_28)[0LL];
  _w2c_mi23 = (storage_28)[2LL];
  _w2c_mi24 = (storage_28)[1LL];
  for(_w2c_contribution2 = 0U; _w2c_contribution2 <= 126LL; _w2c_contribution2 = _w2c_contribution2 + (_INT64)(1U))
  {
    _w2c_mi22 = (((storage_27)[_w2c_contribution2] > _w2c_mi22) || ((storage_27)[_w2c_contribution2] != (storage_27)[_w2c_contribution2]) ? (storage_27)[_w2c_contribution2] : _w2c_mi22);
    _w2c_mi24 = (((storage_27)[_w2c_contribution2 + 127LL] > _w2c_mi24) || ((storage_27)[_w2c_contribution2 + 127LL] != (storage_27)[_w2c_contribution2 + 127LL]) ? (storage_27)[_w2c_contribution2 + 127LL] : _w2c_mi24);
    _w2c_mi23 = (((storage_27)[_w2c_contribution2 + 254LL] > _w2c_mi23) || ((storage_27)[_w2c_contribution2 + 254LL] != (storage_27)[_w2c_contribution2 + 254LL]) ? (storage_27)[_w2c_contribution2 + 254LL] : _w2c_mi23);
  }
  (storage_28)[1LL] = _w2c_mi24;
  (storage_28)[2LL] = _w2c_mi23;
  (storage_28)[0LL] = _w2c_mi22;
  for(_w2c___axis_1_10_11 = 0U; _w2c___axis_1_10_11 <= 2LL; _w2c___axis_1_10_11 = _w2c___axis_1_10_11 + (_INT64)(1U))
  {
    (storage_29)[_w2c___axis_1_10_11] = _F4ABS((storage_28)[_w2c___axis_1_10_11]) <= 3.4028234664e+38F;
    (storage_30)[_w2c___axis_1_10_11] = 0.0F;
    (storage_31)[_w2c___axis_1_10_11] = ((storage_29)[_w2c___axis_1_10_11] ? (storage_28)[_w2c___axis_1_10_11] : (storage_30)[_w2c___axis_1_10_11]);
  }
  _w2c_mi25 = (storage_31)[0LL];
  _w2c_mi26 = (storage_31)[1LL];
  _w2c_mi27 = (storage_31)[2LL];
  for(_w2c_axis_24 = 0U; _w2c_axis_24 <= 126LL; _w2c_axis_24 = _w2c_axis_24 + (_INT64)(1U))
  {
    (storage_32)[_w2c_axis_24] = (storage_27)[_w2c_axis_24] - _w2c_mi25;
    (storage_32)[_w2c_axis_24 + 127LL] = (storage_27)[_w2c_axis_24 + 127LL] - _w2c_mi26;
    (storage_32)[_w2c_axis_24 + 254LL] = (storage_27)[_w2c_axis_24 + 254LL] - _w2c_mi27;
  }
  for(_w2c_axis_25 = 0U; _w2c_axis_25 <= 126LL; _w2c_axis_25 = _w2c_axis_25 + (_INT64)(1U))
  {
    for(_w2c_axis_30 = 0U; _w2c_axis_30 <= 2LL; _w2c_axis_30 = _w2c_axis_30 + (_INT64)(1U))
    {
      (storage_33)[_w2c_axis_25 + (_w2c_axis_30 * (_INT64)(127U))] = F4EXP((storage_32)[_w2c_axis_25 + (_w2c_axis_30 * (_INT64)(127U))]);
    }
  }
  (storage_34)[0LL] = 0.0F;
  (storage_34)[1LL] = 0.0F;
  (storage_34)[2LL] = 0.0F;
  _w2c_mi28 = (storage_34)[0LL];
  _w2c_mi29 = (storage_34)[2LL];
  _w2c_mi30 = (storage_34)[1LL];
  for(_w2c_contribution3 = 0U; _w2c_contribution3 <= 126LL; _w2c_contribution3 = _w2c_contribution3 + (_INT64)(1U))
  {
    _w2c_mi28 = (storage_33)[_w2c_contribution3] + _w2c_mi28;
    _w2c_mi30 = (storage_33)[_w2c_contribution3 + 127LL] + _w2c_mi30;
    _w2c_mi29 = (storage_33)[_w2c_contribution3 + 254LL] + _w2c_mi29;
  }
  (storage_34)[1LL] = _w2c_mi30;
  (storage_34)[2LL] = _w2c_mi29;
  (storage_34)[0LL] = _w2c_mi28;
  for(_w2c____axis_1_12_13_14 = 0U; _w2c____axis_1_12_13_14 <= 2LL; _w2c____axis_1_12_13_14 = _w2c____axis_1_12_13_14 + (_INT64)(1U))
  {
    (storage_35)[_w2c____axis_1_12_13_14] = 0.0F;
    (storage_36)[_w2c____axis_1_12_13_14] = (storage_34)[_w2c____axis_1_12_13_14] > (storage_35)[_w2c____axis_1_12_13_14];
    (storage_37)[_w2c____axis_1_12_13_14] = 1.0F;
    (storage_38)[_w2c____axis_1_12_13_14] = ((storage_36)[_w2c____axis_1_12_13_14] ? (storage_34)[_w2c____axis_1_12_13_14] : (storage_37)[_w2c____axis_1_12_13_14]);
  }
  _w2c_storage_39_1 = 1.0F / (storage_38)[0LL];
  _w2c_storage_39_ = 1.0F / (storage_38)[1LL];
  _w2c_storage_39_0 = 1.0F / (storage_38)[2LL];
  for(_w2c_axis_27 = 0U; _w2c_axis_27 <= 126LL; _w2c_axis_27 = _w2c_axis_27 + (_INT64)(1U))
  {
    (storage_39)[_w2c_axis_27] = (storage_33)[_w2c_axis_27] * _w2c_storage_39_1;
    (storage_39)[_w2c_axis_27 + 127LL] = (storage_33)[_w2c_axis_27 + 127LL] * _w2c_storage_39_;
    (storage_39)[_w2c_axis_27 + 254LL] = (storage_33)[_w2c_axis_27 + 254LL] * _w2c_storage_39_0;
  }
  for(_w2c_axis_ = 0U; _w2c_axis_ <= 11LL; _w2c_axis_ = _w2c_axis_ + (_INT64)(5U))
  {
    (storage_42)[_w2c_axis_] = 0.0F;
    (storage_42)[_w2c_axis_ + 16LL] = 0.0F;
    (storage_42)[_w2c_axis_ + 32LL] = 0.0F;
    (storage_42)[_w2c_axis_ + 1LL] = 0.0F;
    (storage_42)[_w2c_axis_ + 17LL] = 0.0F;
    (storage_42)[_w2c_axis_ + 33LL] = 0.0F;
    (storage_42)[_w2c_axis_ + 2LL] = 0.0F;
    (storage_42)[_w2c_axis_ + 18LL] = 0.0F;
    (storage_42)[_w2c_axis_ + 34LL] = 0.0F;
    (storage_42)[_w2c_axis_ + 3LL] = 0.0F;
    (storage_42)[_w2c_axis_ + 19LL] = 0.0F;
    (storage_42)[_w2c_axis_ + 35LL] = 0.0F;
    (storage_42)[_w2c_axis_ + 4LL] = 0.0F;
    (storage_42)[_w2c_axis_ + 20LL] = 0.0F;
    (storage_42)[_w2c_axis_ + 36LL] = 0.0F;
    _w2c_mi31 = (storage_42)[_w2c_axis_];
    _w2c_mi32 = (storage_42)[_w2c_axis_ + 36LL];
    _w2c_mi33 = (storage_42)[_w2c_axis_ + 20LL];
    _w2c_mi34 = (storage_42)[_w2c_axis_ + 16LL];
    _w2c_mi35 = (storage_42)[_w2c_axis_ + 4LL];
    _w2c_mi36 = (storage_42)[_w2c_axis_ + 35LL];
    _w2c_mi37 = (storage_42)[_w2c_axis_ + 19LL];
    _w2c_mi38 = (storage_42)[_w2c_axis_ + 32LL];
    _w2c_mi39 = (storage_42)[_w2c_axis_ + 3LL];
    _w2c_mi40 = (storage_42)[_w2c_axis_ + 34LL];
    _w2c_mi41 = (storage_42)[_w2c_axis_ + 18LL];
    _w2c_mi42 = (storage_42)[_w2c_axis_ + 1LL];
    _w2c_mi43 = (storage_42)[_w2c_axis_ + 2LL];
    _w2c_mi44 = (storage_42)[_w2c_axis_ + 33LL];
    _w2c_mi45 = (storage_42)[_w2c_axis_ + 17LL];
    for(_w2c_contribution0 = 0U; _w2c_contribution0 <= 126LL; _w2c_contribution0 = _w2c_contribution0 + (_INT64)(1U))
    {
      _w2c_mi31 = _w2c_mi31 + ((storage_2)[_w2c_axis_ + (_w2c_contribution0 * (_INT64)(16U))] * (storage_39)[_w2c_contribution0]);
      _w2c_mi34 = _w2c_mi34 + ((storage_2)[_w2c_axis_ + (_w2c_contribution0 * (_INT64)(16U))] * (storage_39)[_w2c_contribution0 + 127LL]);
      _w2c_mi38 = _w2c_mi38 + ((storage_2)[_w2c_axis_ + (_w2c_contribution0 * (_INT64)(16U))] * (storage_39)[_w2c_contribution0 + 254LL]);
      _w2c_mi42 = _w2c_mi42 + ((storage_2)[(_w2c_axis_ + (_w2c_contribution0 * (_INT64)(16U))) + 1LL] * (storage_39)[_w2c_contribution0]);
      _w2c_mi45 = _w2c_mi45 + ((storage_2)[(_w2c_axis_ + (_w2c_contribution0 * (_INT64)(16U))) + 1LL] * (storage_39)[_w2c_contribution0 + 127LL]);
      _w2c_mi44 = _w2c_mi44 + ((storage_2)[(_w2c_axis_ + (_w2c_contribution0 * (_INT64)(16U))) + 1LL] * (storage_39)[_w2c_contribution0 + 254LL]);
      _w2c_mi43 = _w2c_mi43 + ((storage_2)[(_w2c_axis_ + (_w2c_contribution0 * (_INT64)(16U))) + 2LL] * (storage_39)[_w2c_contribution0]);
      _w2c_mi41 = _w2c_mi41 + ((storage_2)[(_w2c_axis_ + (_w2c_contribution0 * (_INT64)(16U))) + 2LL] * (storage_39)[_w2c_contribution0 + 127LL]);
      _w2c_mi40 = _w2c_mi40 + ((storage_2)[(_w2c_axis_ + (_w2c_contribution0 * (_INT64)(16U))) + 2LL] * (storage_39)[_w2c_contribution0 + 254LL]);
      _w2c_mi39 = _w2c_mi39 + ((storage_2)[(_w2c_axis_ + (_w2c_contribution0 * (_INT64)(16U))) + 3LL] * (storage_39)[_w2c_contribution0]);
      _w2c_mi37 = _w2c_mi37 + ((storage_2)[(_w2c_axis_ + (_w2c_contribution0 * (_INT64)(16U))) + 3LL] * (storage_39)[_w2c_contribution0 + 127LL]);
      _w2c_mi36 = _w2c_mi36 + ((storage_2)[(_w2c_axis_ + (_w2c_contribution0 * (_INT64)(16U))) + 3LL] * (storage_39)[_w2c_contribution0 + 254LL]);
      _w2c_mi35 = _w2c_mi35 + ((storage_2)[(_w2c_axis_ + (_w2c_contribution0 * (_INT64)(16U))) + 4LL] * (storage_39)[_w2c_contribution0]);
      _w2c_mi33 = _w2c_mi33 + ((storage_2)[(_w2c_axis_ + (_w2c_contribution0 * (_INT64)(16U))) + 4LL] * (storage_39)[_w2c_contribution0 + 127LL]);
      _w2c_mi32 = _w2c_mi32 + ((storage_2)[(_w2c_axis_ + (_w2c_contribution0 * (_INT64)(16U))) + 4LL] * (storage_39)[_w2c_contribution0 + 254LL]);
    }
    (storage_42)[_w2c_axis_ + 17LL] = _w2c_mi45;
    (storage_42)[_w2c_axis_ + 33LL] = _w2c_mi44;
    (storage_42)[_w2c_axis_ + 2LL] = _w2c_mi43;
    (storage_42)[_w2c_axis_ + 1LL] = _w2c_mi42;
    (storage_42)[_w2c_axis_ + 18LL] = _w2c_mi41;
    (storage_42)[_w2c_axis_ + 34LL] = _w2c_mi40;
    (storage_42)[_w2c_axis_ + 3LL] = _w2c_mi39;
    (storage_42)[_w2c_axis_ + 32LL] = _w2c_mi38;
    (storage_42)[_w2c_axis_ + 19LL] = _w2c_mi37;
    (storage_42)[_w2c_axis_ + 35LL] = _w2c_mi36;
    (storage_42)[_w2c_axis_ + 4LL] = _w2c_mi35;
    (storage_42)[_w2c_axis_ + 16LL] = _w2c_mi34;
    (storage_42)[_w2c_axis_ + 20LL] = _w2c_mi33;
    (storage_42)[_w2c_axis_ + 36LL] = _w2c_mi32;
    (storage_42)[_w2c_axis_] = _w2c_mi31;
  }
  (storage_42)[15LL] = 0.0F;
  (storage_42)[31LL] = 0.0F;
  (storage_42)[47LL] = 0.0F;
  _w2c_mi46 = (storage_42)[15LL];
  _w2c_mi47 = (storage_42)[31LL];
  _w2c_mi48 = (storage_42)[47LL];
  for(_w2c_contribution0 = 0U; _w2c_contribution0 <= 126LL; _w2c_contribution0 = _w2c_contribution0 + (_INT64)(1U))
  {
    _w2c_mi46 = _w2c_mi46 + ((storage_2)[(_w2c_contribution0 * (_INT64)(16U)) + 15LL] * (storage_39)[_w2c_contribution0]);
    _w2c_mi47 = _w2c_mi47 + ((storage_2)[(_w2c_contribution0 * (_INT64)(16U)) + 15LL] * (storage_39)[_w2c_contribution0 + 127LL]);
    _w2c_mi48 = _w2c_mi48 + ((storage_2)[(_w2c_contribution0 * (_INT64)(16U)) + 15LL] * (storage_39)[_w2c_contribution0 + 254LL]);
  }
  (storage_42)[47LL] = _w2c_mi48;
  (storage_42)[31LL] = _w2c_mi47;
  (storage_42)[15LL] = _w2c_mi46;
  for(_w2c_axis_16 = 0U; _w2c_axis_16 <= 15LL; _w2c_axis_16 = _w2c_axis_16 + (_INT64)(2U))
  {
    for(_w2c_axis_18 = 0U; _w2c_axis_18 <= 5LL; _w2c_axis_18 = _w2c_axis_18 + (_INT64)(1U))
    {
      (storage_45)[_w2c_axis_18 + (_w2c_axis_16 * (_INT64)(6U))] = (storage_5)[_w2c_axis_16 + (_w2c_axis_18 * (_INT64)(16U))];
      (storage_45)[(_w2c_axis_18 + (_w2c_axis_16 * (_INT64)(6U))) + 96LL] = (storage_5)[(_w2c_axis_16 + (_w2c_axis_18 * (_INT64)(16U))) + 96LL];
      (storage_45)[(_w2c_axis_18 + (_w2c_axis_16 * (_INT64)(6U))) + 192LL] = (storage_5)[(_w2c_axis_16 + (_w2c_axis_18 * (_INT64)(16U))) + 192LL];
      (storage_45)[_w2c_axis_18 + ((_w2c_axis_16 + 1LL) * (_INT64)(6U))] = (storage_5)[(_w2c_axis_16 + (_w2c_axis_18 * (_INT64)(16U))) + 1LL];
      (storage_45)[(_w2c_axis_18 + ((_w2c_axis_16 + 1LL) * (_INT64)(6U))) + 96LL] = (storage_5)[(_w2c_axis_16 + (_w2c_axis_18 * (_INT64)(16U))) + 97LL];
      (storage_45)[(_w2c_axis_18 + ((_w2c_axis_16 + 1LL) * (_INT64)(6U))) + 192LL] = (storage_5)[(_w2c_axis_16 + (_w2c_axis_18 * (_INT64)(16U))) + 193LL];
    }
  }
  for(_w2c_axis_31 = 0U; _w2c_axis_31 <= 2LL; _w2c_axis_31 = _w2c_axis_31 + (_INT64)(1U))
  {
    for(_w2c_axis_22 = 0U; _w2c_axis_22 <= 5LL; _w2c_axis_22 = _w2c_axis_22 + (_INT64)(1U))
    {
      (storage_46)[_w2c_axis_22 + (_w2c_axis_31 * (_INT64)(6U))] = 0.0F;
    }
  }
  for(_w2c_contribution4 = 0U; _w2c_contribution4 <= 15LL; _w2c_contribution4 = _w2c_contribution4 + (_INT64)(4U))
  {
    _w2c_mi49 = (storage_42)[_w2c_contribution4];
    _w2c_mi50 = (storage_42)[_w2c_contribution4 + 16LL];
    _w2c_mi51 = (storage_42)[_w2c_contribution4 + 35LL];
    _w2c_mi52 = (storage_42)[_w2c_contribution4 + 32LL];
    _w2c_mi53 = (storage_42)[_w2c_contribution4 + 19LL];
    _w2c_mi54 = (storage_42)[_w2c_contribution4 + 1LL];
    _w2c_mi55 = (storage_42)[_w2c_contribution4 + 3LL];
    _w2c_mi56 = (storage_42)[_w2c_contribution4 + 17LL];
    _w2c_mi57 = (storage_42)[_w2c_contribution4 + 34LL];
    _w2c_mi58 = (storage_42)[_w2c_contribution4 + 33LL];
    _w2c_mi59 = (storage_42)[_w2c_contribution4 + 18LL];
    _w2c_mi60 = (storage_42)[_w2c_contribution4 + 2LL];
    for(_w2c_axis_22 = 0U; _w2c_axis_22 <= 5LL; _w2c_axis_22 = _w2c_axis_22 + (_INT64)(1U))
    {
      (storage_46)[_w2c_axis_22] = (storage_46)[_w2c_axis_22] + ((storage_45)[_w2c_axis_22 + (_w2c_contribution4 * (_INT64)(6U))] * _w2c_mi49);
      (storage_46)[_w2c_axis_22 + 6LL] = (storage_46)[_w2c_axis_22 + 6LL] + ((storage_45)[(_w2c_axis_22 + (_w2c_contribution4 * (_INT64)(6U))) + 96LL] * _w2c_mi50);
      (storage_46)[_w2c_axis_22 + 12LL] = (storage_46)[_w2c_axis_22 + 12LL] + ((storage_45)[(_w2c_axis_22 + (_w2c_contribution4 * (_INT64)(6U))) + 192LL] * _w2c_mi52);
      (storage_46)[_w2c_axis_22] = (storage_46)[_w2c_axis_22] + ((storage_45)[_w2c_axis_22 + ((_w2c_contribution4 + 1LL) * (_INT64)(6U))] * _w2c_mi54);
      (storage_46)[_w2c_axis_22 + 6LL] = (storage_46)[_w2c_axis_22 + 6LL] + ((storage_45)[(_w2c_axis_22 + ((_w2c_contribution4 + 1LL) * (_INT64)(6U))) + 96LL] * _w2c_mi56);
      (storage_46)[_w2c_axis_22 + 12LL] = (storage_46)[_w2c_axis_22 + 12LL] + ((storage_45)[(_w2c_axis_22 + ((_w2c_contribution4 + 1LL) * (_INT64)(6U))) + 192LL] * _w2c_mi58);
      (storage_46)[_w2c_axis_22] = (storage_46)[_w2c_axis_22] + ((storage_45)[_w2c_axis_22 + ((_w2c_contribution4 + 2LL) * (_INT64)(6U))] * _w2c_mi60);
      (storage_46)[_w2c_axis_22 + 6LL] = (storage_46)[_w2c_axis_22 + 6LL] + ((storage_45)[(_w2c_axis_22 + ((_w2c_contribution4 + 2LL) * (_INT64)(6U))) + 96LL] * _w2c_mi59);
      (storage_46)[_w2c_axis_22 + 12LL] = (storage_46)[_w2c_axis_22 + 12LL] + ((storage_45)[(_w2c_axis_22 + ((_w2c_contribution4 + 2LL) * (_INT64)(6U))) + 192LL] * _w2c_mi57);
      (storage_46)[_w2c_axis_22] = (storage_46)[_w2c_axis_22] + ((storage_45)[_w2c_axis_22 + ((_w2c_contribution4 + 3LL) * (_INT64)(6U))] * _w2c_mi55);
      (storage_46)[_w2c_axis_22 + 6LL] = (storage_46)[_w2c_axis_22 + 6LL] + ((storage_45)[(_w2c_axis_22 + ((_w2c_contribution4 + 3LL) * (_INT64)(6U))) + 96LL] * _w2c_mi53);
      (storage_46)[_w2c_axis_22 + 12LL] = (storage_46)[_w2c_axis_22 + 12LL] + ((storage_45)[(_w2c_axis_22 + ((_w2c_contribution4 + 3LL) * (_INT64)(6U))) + 192LL] * _w2c_mi51);
    }
  }
  for(_w2c______axis_1_16_17_18_19_20 = 0U; _w2c______axis_1_16_17_18_19_20 <= 2LL; _w2c______axis_1_16_17_18_19_20 = _w2c______axis_1_16_17_18_19_20 + (_INT64)(1U))
  {
    (storage_48)[_w2c______axis_1_16_17_18_19_20] = 0.0F;
    (storage_49)[_w2c______axis_1_16_17_18_19_20] = (storage_34)[_w2c______axis_1_16_17_18_19_20] > (storage_48)[_w2c______axis_1_16_17_18_19_20];
    (storage_50)[_w2c______axis_1_16_17_18_19_20] = F4LOG((storage_38)[_w2c______axis_1_16_17_18_19_20]);
    (storage_51)[_w2c______axis_1_16_17_18_19_20] = (storage_31)[_w2c______axis_1_16_17_18_19_20] + (storage_50)[_w2c______axis_1_16_17_18_19_20];
    (storage_52)[_w2c______axis_1_16_17_18_19_20] = -infF;
    (storage_53)[_w2c______axis_1_16_17_18_19_20] = ((storage_49)[_w2c______axis_1_16_17_18_19_20] ? (storage_51)[_w2c______axis_1_16_17_18_19_20] : (storage_52)[_w2c______axis_1_16_17_18_19_20]);
  }
  for(_w2c_axis_26 = 0U; _w2c_axis_26 <= 5LL; _w2c_axis_26 = _w2c_axis_26 + (_INT64)(1U))
  {
    (storage_7)[_w2c_axis_26] = (storage_46)[_w2c_axis_26];
    (storage_7)[_w2c_axis_26 + 6LL] = (storage_46)[_w2c_axis_26 + 6LL];
    (storage_7)[_w2c_axis_26 + 12LL] = (storage_46)[_w2c_axis_26 + 12LL];
  }
  for(_w2c_axis_0 = 0U; _w2c_axis_0 <= 2LL; _w2c_axis_0 = _w2c_axis_0 + (_INT64)(1U))
  {
    (storage_8)[_w2c_axis_0] = (storage_53)[_w2c_axis_0];
  }
  return;
} /* open64_common_high */

