#!/bin/bash
set -eu
. /case/environment.sh
export LD_LIBRARY_PATH=/toolchain/current/be:/toolchain/current/wopt:/toolchain/current/lno:/toolchain/current/ipl:/toolchain/current/whirl2c
exec /toolchain/current/ir_tools/ir_b2a -st -src /case/short.input.B /case/short.input.T
