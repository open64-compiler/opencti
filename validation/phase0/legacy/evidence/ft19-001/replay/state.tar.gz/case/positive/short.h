/* Include builtin types and operators.*/
/* It is like under $TOOLROOT/include/$REL_VER/ */
#include <whirl2c.h>

/* Types */
/* File-level vars and routines */
extern void open64_common_high(_IEEE32 * restrict, _IEEE32 * restrict, _IEEE32 * restrict, _IEEE32 * restrict, _IEEE32 * restrict, _IEEE32 * restrict, _UINT8 * restrict, _IEEE32 * restrict, _IEEE32 * restrict, _IEEE32 * restrict, _IEEE32 * restrict, _IEEE32 * restrict, _IEEE32 * restrict, _IEEE32 * restrict, _IEEE32 * restrict, _IEEE32 * restrict, _IEEE32 * restrict, _UINT8 * restrict, _IEEE32 * restrict, _IEEE32 * restrict, _IEEE32 * restrict, _UINT8 * restrict, _IEEE32 * restrict, _IEEE32 * restrict, _IEEE32 * restrict, _IEEE32 * restrict, _IEEE32 * restrict, _IEEE32 * restrict, _UINT8 * restrict, _IEEE32 * restrict, _IEEE32 * restrict, _IEEE32 * restrict, _IEEE32 * restrict, _IEEE32 * restrict, _IEEE32 * restrict, _IEEE32 * restrict, _UINT8 * restrict, _IEEE32 * restrict, _IEEE32 * restrict, _IEEE32 * restrict, _IEEE32 * restrict);

