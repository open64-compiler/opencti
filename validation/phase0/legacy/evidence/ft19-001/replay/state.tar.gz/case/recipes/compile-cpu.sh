#!/bin/bash
set -eu
. /case/environment.sh
export LD_LIBRARY_PATH=/toolchain/current/be:/toolchain/current/wopt:/toolchain/current/lno:/toolchain/current/ipl:/toolchain/current/whirl2c
exec gcc -std=c99 -O2 -shared -fPIC -ffp-contract=off -fno-fast-math -I/toolchain/include -include /src/osprey/be/lno/tests/common_high_host.h /case/positive/short.c -lm -o /case/positive/short.so
