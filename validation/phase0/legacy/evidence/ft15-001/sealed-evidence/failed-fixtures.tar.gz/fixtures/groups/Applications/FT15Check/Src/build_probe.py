import sys,json
from pathlib import Path
with Path('build-options.jsonl').open('a') as f:
    f.write(json.dumps({'cc':sys.argv[1],'cflags':sys.argv[2],'unit_opt_level':sys.argv[3]})+'\n')
