int main( { deliberate_compile_failure; }
