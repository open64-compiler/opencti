#include <stdio.h>
int main(void) { printf("application flag=%d\n", FT15_FLAG); return 0; }
