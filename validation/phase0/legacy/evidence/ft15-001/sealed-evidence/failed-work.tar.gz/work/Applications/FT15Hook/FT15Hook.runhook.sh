#!/bin/bash
/opt/cti/bin/gmake -f Makefile check >> hook-check.log 2>&1
RET=$?
printf '%s\n' "$RET" >> hook-status.log
exit "$RET"
