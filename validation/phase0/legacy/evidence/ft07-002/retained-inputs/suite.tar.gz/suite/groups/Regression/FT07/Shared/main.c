#include <stdio.h>
#include <unistd.h>
#include "header_alias.h"
extern const char *ft07_support(void);
extern const char *ft07_mode(void);
int main(void) {
    printf("pid=%ld|%s|%s|%s\n", (long)getpid(), ft07_support(), FT07_HEADER, ft07_mode());
    return 0;
}
