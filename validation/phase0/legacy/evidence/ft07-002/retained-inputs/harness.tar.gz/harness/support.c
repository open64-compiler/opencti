#include "support-include.h"
const char *ft07_support(void) { return "support-A"; }
const char *ft07_mode(void) { return FT07_BUILD_MODE; }
