#ifndef FT07_SHARED_H
#define FT07_SHARED_H
#define FT07_HEADER "header-A"
#endif
