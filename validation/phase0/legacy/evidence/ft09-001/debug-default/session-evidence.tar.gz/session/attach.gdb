set pagination off
set confirm off
set debuginfod enabled off
set disable-randomization off
printf "FT09_VALUE_BEFORE=%d\n", debug_value
info source
list main
break debug_checkpoint
set var debug_value=42
continue
printf "FT09_VALUE_AFTER=%d\n", debug_value
bt
list
detach
quit
