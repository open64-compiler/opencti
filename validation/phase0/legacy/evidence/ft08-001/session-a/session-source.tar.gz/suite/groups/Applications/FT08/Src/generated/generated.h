#define FT08_MESSAGE "approved"
