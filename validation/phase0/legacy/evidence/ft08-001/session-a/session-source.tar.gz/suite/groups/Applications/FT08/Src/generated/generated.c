#include <stdio.h>
#include "generated.h"
int main(void) { puts(FT08_MESSAGE); return 0; }
