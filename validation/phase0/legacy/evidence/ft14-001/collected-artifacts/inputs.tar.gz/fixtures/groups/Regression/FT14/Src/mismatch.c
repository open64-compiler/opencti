#include <stdio.h>
int main(void) {
    char input[40];
    FILE *f = fopen("/fixtures/data/input.txt", "r");
    if (!f || !fgets(input, sizeof input, f)) return 23;
    fclose(f);
    printf("observed seed=%d input=%s", FT14_SEED, input);
    return 0;
}
