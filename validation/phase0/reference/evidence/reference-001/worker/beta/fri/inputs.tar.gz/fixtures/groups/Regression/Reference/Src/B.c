#error retained-known-compile-failure
