#error expected-compile-rejection
