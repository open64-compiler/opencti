#include <stdio.h>
int main(void){puts("approved");return 0;}
